app.controller('dashboardController', function ($scope, $http, $location, $routeParams) {

    $scope.lista = [{
            tipoDespesa: {
                descricao: 'carro',
                cor: '#F00'
            },
            dataInicial: new Date().getMilliseconds(),
            dataFinal: new Date().getMilliseconds(),
            valor: 100,
            valorConsolidado: 50
        },
        {
            tipoDespesa: {
                descricao: 'carro',
                cor: '#F00'
            },
            dataInicial: new Date().getMilliseconds(),
            dataFinal: new Date().getMilliseconds(),
            valor: 100,
            valorConsolidado: 90
        },

        {
            tipoDespesa: {
                descricao: 'carro',
                cor: '#F00'
            },
            dataInicial: new Date().getMilliseconds(),
            dataFinal: new Date().getMilliseconds(),
            valor: 100,
            valorConsolidado: 71
        }];


});